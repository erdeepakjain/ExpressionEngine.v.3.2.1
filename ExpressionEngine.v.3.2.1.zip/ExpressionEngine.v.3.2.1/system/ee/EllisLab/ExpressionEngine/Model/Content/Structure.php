<?php

namespace EllisLab\ExpressionEngine\Model\Content;

interface Structure {

}

// EOF
