<?php

namespace EllisLab\ExpressionEngine\Model\Content;

use EllisLab\ExpressionEngine\Service\Model\Model;

abstract class StructureModel extends Model implements Structure {


}

// EOF
