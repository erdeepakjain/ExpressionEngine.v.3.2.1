<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Emoticon',
	'description' => '',
	'version'     => '2.0',
	'namespace'   => 'EllisLab\Addons\Emoticon',
	'settings_exist' => FALSE,
);