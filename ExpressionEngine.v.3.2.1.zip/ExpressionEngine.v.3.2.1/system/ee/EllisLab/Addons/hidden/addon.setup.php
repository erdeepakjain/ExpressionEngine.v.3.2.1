<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => '',
	'name'           => 'Hidden Field',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\HiddenField',
	'settings_exist' => FALSE,
	'built_in'       => TRUE
);