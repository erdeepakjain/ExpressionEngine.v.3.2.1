<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => '',
	'name'           => 'Search',
	'description'    => '',
	'version'        => '2.2.2',
	'namespace'      => 'EllisLab\Addons\Search',
	'settings_exist' => FALSE,
	'built_in'       => TRUE
);