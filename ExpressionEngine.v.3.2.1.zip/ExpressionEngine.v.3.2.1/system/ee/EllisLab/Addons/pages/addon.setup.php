<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Pages',
	'description' => '',
	'version'     => '2.2',
	'namespace'   => 'EllisLab\Addons\Foo',
	'settings_exist' => TRUE,
);