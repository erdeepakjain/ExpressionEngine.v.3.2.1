<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Blacklist',
	'description' => '',
	'version'     => '3.0.1',
	'namespace'   => 'EllisLab\Addons\Blacklist',
	'settings_exist' => TRUE,
);