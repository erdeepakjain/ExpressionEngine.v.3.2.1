<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Query',
	'description' => '',
	'version'     => '2.0',
	'namespace'   => 'EllisLab\Addons\Query',
	'settings_exist' => FALSE,
);