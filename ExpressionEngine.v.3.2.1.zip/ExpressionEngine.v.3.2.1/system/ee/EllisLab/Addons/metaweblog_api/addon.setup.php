<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Metaweblog_api',
	'description' => '',
	'version'     => '2.2',
	'namespace'   => 'EllisLab\Addons\MetaweblogApi',
	'settings_exist' => TRUE,
);