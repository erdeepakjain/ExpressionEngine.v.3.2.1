<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => '',
	'name'           => 'File',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\File',
	'settings_exist' => FALSE,
	'built_in'       => TRUE
);