<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * ExpressionEngine - by EllisLab
 *
 * @package		ExpressionEngine
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2003 - 2016, EllisLab, Inc.
 * @license		
 * @link		
 * @since		Version 2.0
 */

// ------------------------------------------------------------------------

/**
 * ExpressionEngine Stats Module Control Panel Class
 *
 * @package		ExpressionEngine
 * @subpackage	Modules
 * @category	Stats Module
 * @author		EllisLab Dev Team
 * @link		
 */

class Stats_mcp {

}
// END CLASS

// EOF
