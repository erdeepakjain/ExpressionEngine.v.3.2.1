<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => '',
	'name'        => 'Email',
	'description' => '',
	'version'     => '2.1',
	'namespace'   => 'EllisLab\Addons\Email',
	'settings_exist' => FALSE,
);